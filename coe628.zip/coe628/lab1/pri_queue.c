#include <stdlib.h>
#include <stdio.h>
#include "pri_queue.h"
/** @file pri_queue.c */
static Node_ptr_t head = NULL;
/**
 * Insert a Node into a priority queue.
 * @param priority
 * @param data
 * @author
 */
void PQ_insert(int priority, char * data) {
    Node_ptr_t node = (struct node*)
            malloc(sizeof(struct node));
    node->priority = priority;
    node->data = data;
    
    int index = 1;
    
    if (head == NULL) {
        head = node;
        head->next = NULL;
    }
    else if (node->priority > head->priority){
        //Node_ptr_t node = head;
        node->next = head;
        head = node;
        //head->next = node;
    }
    
    while ( !(head == NULL) && !(node->priority >= head->priority) && (index == 1)){
        Node_ptr_t n;
        for(n = head; n != NULL; n = n->next){
            if(node->priority < n->priority && (node->priority > n->next->priority || n->next == NULL)) {
                node->next = n->next;
                n->next = node;
                index = 2;
                
            }
        }
    }
}
/**
 * Delete and return the node with the highest priority.
 * @return The highest priority Node.
 */
Node_ptr_t PQ_delete() {
    Node_ptr_t n = head->next;
    head = n;
    return head;
}

/**
 * Do NOT modify this function.
 * @return A pointer to the head of the list.  (NULL if list is empty.)
 */
Node_ptr_t PQ_get_head() {
    return head;
}

/**
 * Do NOT modify this function.
 * @return the number of items in the queue
 */
int PQ_get_size() {
    int size = 0;
    Node_ptr_t tmp;
    for(tmp = head; tmp != NULL; tmp = tmp->next, size++)
        ;
    return size;
}


