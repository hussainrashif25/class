/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9;
/*When using semaphores from the class in lab 8, the code run's forever but doesnt end. In this version i have
implemented my own semaphore check within the code
*/

public class Lab9 {

    private static final int n = 4;

    static int finished = 0;
    Fork availableforks[] = new Fork[n];
    Philosopher status[] = new Philosopher[n];

    void initialize() {
        for (int i = 0; i < n; i++) {
            availableforks[i] = new Fork();
            status[i] = new Philosopher();
            availableforks[i].taken = status[i].left = status[i].right = 0;
        }
    }

    void test(int id) { 

        if (status[id].left == 10 && status[id].right == 10)

            System.out.println("Philosopher " + (id + 1) + " completed his dinner");

        else if (status[id].left == 1 && status[id].right == 1) {

            System.out.println("Philosopher " + (id + 1) + " completed his dinner");
            status[id].left = status[id].right = 10; 
            int otherFork = id - 1;

            if (otherFork == -1) {
                otherFork = (n - 1);
            }
            
            availableforks[id].taken = availableforks[otherFork].taken = 0; 
            System.out.println( "Philosopher " + (id + 1) + " released fork " + (id + 1) + " and fork " + (otherFork + 1));
            finished++;
        }
        else if (status[id].left == 1 && status[id].right == 0) { 
            if (id == (n - 1)) {
                if (availableforks[id].taken == 0) { 
                    availableforks[id].taken = status[id].right = 1;
                    System.out.println("Fork " + (id + 1) + " taken by philosopher " + (id + 1));
                } else {
                    System.out.println("Philosopher " + (id + 1) + " is waiting for fork " + (id + 1));
                }
            } else { 
                int dupid = id;
                id -= 1;
                
                if (id == -1) {
                    id = (n - 1);
                }
                if (availableforks[id].taken == 0) {
                    availableforks[id].taken = status[dupid].right = 1;
                    System.out.println("Fork " + (id + 1) + " taken by Philosopher " + (dupid + 1));
                } else {
                    System.out.println("Philosopher " + (dupid + 1) + " is waiting for Fork " + (id + 1));
                }
            }
        }
        else if (status[id].left == 0) { 
            if (id == (n - 1)) {
                if (availableforks[id - 1].taken == 0) { 
                    availableforks[id - 1].taken = status[id].left = 1;
                    System.out.println("Fork " + id + " taken by philosopher " + (id + 1));
                } else {
                    System.out.println("Philosopher " + (id + 1) + " is waiting for fork " + id);
                }
            } else { 
                if (availableforks[id].taken == 0) {
                    availableforks[id].taken = status[id].left = 1;
                    System.out.println("Fork " + (id + 1) + " taken by Philosopher " + (id + 1));
                } else {
                    System.out.println("Philosopher " + (id + 1) + " is waiting for Fork " + (id + 1));
                }
            }
        } 
    }

    public static void main(String args[]) {
        
        Lab9 start = new Lab9();
        start.initialize();

        while (finished < n) {
            for (int i = 0; i < n; i++){
                start.test(i);
            }
            System.out.println("Till now num of philosophers completed dinner are " + finished);
        }

    }
}