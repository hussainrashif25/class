/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Mohammad Rashif Hussain
 *
 * Created on February 1, 2020, 9:14 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/wait.h>

/*
 * 
 */
int main(int argc, char** argv) {
    
    char input[100];
    char command[100];
    char a[100];
    char b[100];
    int ch;
    int index = 0;
    char delim[] = "&";
    char *ptr;
    int status;
    char *find;
    pid_t pid, wpid;
    char *a1;
    char **one;
    
    
    
    while(1) {
        //sleep(1);
        printf("\nYour Command>");
        while ( (ch = getchar()) != '\n') {
            input[index] = ch;
            index++;
        }
        input[index] = '\0';
        strcpy(command, input);
        memset(input, 0, 100);
        
        find = strstr(command, delim);
        if (find != NULL) {
            ptr = strtok(command, delim);
            strcpy(a,ptr);
            while (ptr != NULL) {
                strcpy(b, ptr);
                ptr = strtok(NULL, delim);
            }
        }
        else {
            strcpy(a,command);
            strcpy(b, "x");
        }
         // printf("%s\n",a);
       //  printf("%s\n",b);  
        
    
        
        //strcpy(parse,input);
        
    
       //ptr = strtok(parse, delim);
       
        /*while(ptr != NULL) {
            //printf("\n%s", ptr);
            //strcpy(command, ptr);
            command[findex] = ptr;
            findex++;
            ptr = strtok(NULL, delim);
        }
        command[findex] = '\0';
        printf("%s", command);*/
        
        //printf("%s", ptr);
        
        
        //printf("%s",input);
        
        //system(input);

        pid = fork();
        if (pid == -1) {
            printf("\n Error forking child");
        }
        else if (pid == 0) {
            printf("\nThe child has Spawned %d", pid);
            if (strcmp(b,"x") == 0) {
                    system(a);
            }
            else {
                system(a);
                system(b);
            }
            //exit(1);
            //exit(0);
        } 
        
        else {
            printf("The parent process is waiting %d\n", pid);
            wpid = waitpid(pid,&status, 0);
            printf("\nThe child has been killed %d", wpid);
           
        }
        
        
    }
    
    
    /*ptr = strtok(input,delim);
    while (ptr != NULL) {
        parsed[findex] = ptr;
        findex++;
    }
    ptr = strtok(NULL, delim);
    printf("%s",parsed);
    printf("%s",ptr);
        
    */
    
    
    
   
    
    /*char *ptr = strtok(input, delim);
    
    while (ptr != NULL) {
        parsed[findex] = ptr;
        findex++;
    }*/
    
    //int length = s
    
    
    
    //input = getchar();
    //fork();
    //system(input);
    
    return (EXIT_SUCCESS);
}



