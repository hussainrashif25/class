/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: blaze
 *
 * Created on February 9, 2020, 7:10 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int execute(char **com){
    int fd[2];
    pid_t p1, p2;
    char **com1 = malloc(64 * sizeof(char*));
    char **com2 = malloc(64 * sizeof(char*));
   /* for (int i = 0; i < 5; i++) {
            printf("\n%s", *com);
            com++;
        }*/
    
    for (int i = 0; i < 5; i++) {
        if (com[i] == NULL) {
            com1 = com - 2;
            //printf("\n%s", *com1);
            com2 = com;
            //printf("\n%s", *com2);
            break;
        }
        com++;
        //printf("%s",&com);
    }
    char *cmd1 = com1[0];
    char *argv1[1];
    argv1[0] = com1[0];
    argv1[1] = "\0";
    printf("\n%s", cmd1);
    //printf("\n%s", *argv1);
    for (int i = 0; i < 2; i++) {
            printf("\n%s", *argv1);
            argv1[i];
        }
    char *cmd2 = com2[0];
    char *argv2[1];
    argv2[0] = com2[0];
    argv2[1] = "\0";
    printf("\n%s", cmd2);
    //printf("\n%s", *argv2);
    for (int i = 0; i < 2; i++) {
            printf("\n%s", *argv2);
            argv2[i];
        }
    
    //execvp(com1[0], com);
    if ((p1 = fork()) == 0) {
        dup2(fd[1], STDOUT_FILENO); 
        close(fd[0]);

        close(fd[1]);
        if ((execvp(cmd1, *argv1)) < 0) {
            printf("\nCould not execute");
            exit(0);
        }
    }
    else {
        if ((p2 = fork()) == 0) {
            dup2(fd[0], STDIN_FILENO);
            close(fd[1]);
            close(fd[0]);
            if ((execvp(cmd2, *argv2)) < 0) {
                printf("\nCould not execute 2");
                exit(0);
            }
        }
        else{
            wait(NULL);
            wait(NULL);
        }
    }
    
    return 1;
}

/*int execute(char **com){
    pid_t pid, wpid;
    int status;
    pid = fork();
    if (pid == 0) {
        if (execvp(com[0], com) == -1) {
            printf("\n Command didn't run");
        }
        exit(EXIT_FAILURE);
    } 
    else {
        do {
            wpid = waitpid(pid, &status, WUNTRACED);
            printf("%d",wpid);
        } while (!WIFEXITED(status) && !WIFSIGNALED(status));
    }
    return 1;
    
}*/

char **parseinput(char *s) {
    int i = 0;
    char **data = malloc(64 * sizeof(char*));
    char *ptr;
    
    ptr = strtok(s, "|");
    data[i] = ptr;
    i++;
    data[i] = NULL;
    ptr = strtok(NULL, "|");
    i++;
    data[i] = ptr;
    i++;
    data[i] = NULL;
    //ptr = strtok(NULL, "|");
    
    return data;
    
} 

/*char **parseinput(char *s) {
    int i = 0;
    char **data = malloc(64 * sizeof(char*));
    char *ptr;
    
    ptr = strtok(s, " ");
    while (ptr != NULL) {
        //printf("%s", ptr);
        data[i] = ptr;
        i++;
        ptr = strtok(NULL, " ");
    }
    data[i] = NULL;
    return data;
    
}*/

char *getinput(void) {
    char *line = NULL;
    ssize_t buf = 0;
    getline(&line, &buf, stdin);
    return line;
}

int main(int argc, char** argv) {
    
    char *input;
    char **cmd;
    char *t = "ls\0";
    char **test = &t;
    int status;
    
    while(1) {
        printf(">");
        input = getinput();
        cmd = parseinput(input);
        //printf("%s", *cmd);
        
        status = execute(cmd);
        
        //printf("%s",input);
        /*for (int i = 0; i < 4; i++) {
            printf("%s", *cmd);
            cmd++;
        }*/
        
        
        free(input);
        free(cmd);
    }

    return (EXIT_SUCCESS);
}

