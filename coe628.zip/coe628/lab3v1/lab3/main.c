/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: blaze
 *
 * Created on February 2, 2020, 6:24 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<sys/wait.h>
#include<unistd.h>

char **getinput(char *);

int main(int argc, char** argv) {
    char **com;
    char *input = malloc(sizeof(char) * 100);
    int status;
    pid_t pid, wpid;
    int ch;
    int index = 0;
    
    while (1) {
        printf("\nYour Command>");
        while ( (ch = getchar()) != '\n') {
            input[index] = ch;
            index++;
        }
        input[index] = '\0';
        com = getinput(input);
        //printf("%d",index);
        //printf("%s",**com);
        
        pid = fork();
        if (pid == 0) {
            if (execvp(com[0], com) < 0) {
                printf("\nThe child has Spawned %d", pid);
                exit(1);
            }
        }
        else {
            wpid = waitpid(pid, &status, 0);
            printf("\nThe child has been killed %d", wpid);
        }
        //free(input);
        //free(com);
    }
    return (EXIT_SUCCESS);
}

char **getinput(char *input) {
    char **com = malloc(sizeof(char *) * 100);
    char *delim = "&";
    char *ptr;
    int i = 0;
    
    ptr = strtok(input, delim);
    while (ptr != NULL) {
        com[i] = ptr;
        i++;
        ptr = strtok(NULL, delim);
    }
    com[i] = NULL;
    return com;
}

